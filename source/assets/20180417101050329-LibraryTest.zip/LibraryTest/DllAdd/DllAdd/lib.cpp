#include "lib.h"

LIB_API
int _stdcall add(int x, int y)
{
	return x + y;
}
