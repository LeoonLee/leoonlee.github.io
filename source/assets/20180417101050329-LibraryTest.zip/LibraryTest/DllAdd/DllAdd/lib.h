#ifndef __LIB_H__
#define __LIB_H__

#ifdef DLLADD_EXPORTS

#define LIB_API extern "C" _declspec(dllexport)

#else

#define LIB_API extern "C" _declspec(dllimport) 

#endif

LIB_API int _stdcall add(int x, int y);

#endif
