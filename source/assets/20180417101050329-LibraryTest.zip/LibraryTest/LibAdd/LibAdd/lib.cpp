#include "stdafx.h"
#include "lib.h"

int add(const int x, const int y)
{
	return x + y;
}
